<?php
// Example Code + Description by CoolRunner82
require_once("vendor/autoload.php"); 
// 1. Activate cloudvision api in google https://cloud.google.com/vision/ (console) You will need a Creditcard.
// Don´t worry, nothing will be charged. This is for verification only.
// You have 1000 API calls for free each month. Even after that, google will not charge anything without your explicit approval.
// 2. create a project and add an "service account key" (Dienstkontoschlüssel in german) for that project.
// 3. You can download your json File (for authentication). Upload your file to your twdtool.
// You may have to rename your File here from key to your json Filename
putenv('GOOGLE_APPLICATION_CREDENTIALS=key.json');
use Google\Cloud\Vision\VisionClient;
$vision = new VisionClient();
$imageResource = fopen("image.jpg", 'r'); #<- images from upload2api image param
$image = $vision->image($imageResource, ['DOCUMENT_TEXT_DETECTION']);
$result = $vision->annotate($image);
$document = $result->fullText();
$ocrresult = $document->text();
$ocrresult = str_replace(' ','',$ocrresult);
$ocrresult = preg_replace("/[\r\n]+[\s\t]*[\r\n]+/","\n", $ocrresult);
$array = preg_split("/\r\n|\n|\r/", $ocrresult); //<- Extracted Imagetext in Array Pieces, Name, Exp, etc...
?>